############################################################################
############################################################################
###########                                                      ###########
###########          Simulation study, round 2 (aps-lm)          ###########
###########             Author: Benjamin Planterose              ###########
###########                                                      ###########
###########        Erasmus MC University Medical Centre          ###########
###########               Rotterdam, The Netherlands             ###########
###########                                                      ###########
###########              b.planterosejimenez@gmail.com           ###########
###########                                                      ###########
############################################################################
############################################################################

# Load libraries
library(matrixcalc)
library(MASS)
library(gplots)
library(mice)
library(gtools)
library(matrixStats)
library(ggplot2)
library(reshape)
library(Matrix)
library(fastmatrix)
library(DescTools)

# Load functions
# Common functions
source("common_functions.R")

# Global simulation wrapper
simulation <- function(mu, Cov, theta, p_h, N_iter, conditions, dep, cost_function)
{
  
  results <- expand.grid(c("full", "mean", "MICE", "cmb_LM"), 
                         c("MCAR", "MAR_L", "MAR_R", "MAR_LR", "MAR_C", "MNAR_L", "MNAR_R","MNAR_LR", "MNAR_C"),
                         conditions$pNA) # Assumes n and R^2 are constant
  colnames(results) = c("model", "typeNA", "pNA")
  results$score = ""
  results$score2 = ""
  
  for(i in 1:nrow(conditions))
  {
    pNA = conditions[i,"pNA"]
    print(paste(i, "out of", nrow(conditions)))
    for(l in 1:N_iter)
    {
      k = min(which(results$pNA == pNA))
      # 1. Data generation
      data = data_generation(n = n, mu = mu, Cov = Cov, theta = theta, R2 = R2)
      
      # 2. Splitting
      data = split(data = data, p_h = p_h, n = n)
      
      # 3. N/A injection
      # MCAR
      typeNA = "MCAR"; subtype = NULL
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      
      # MAR
      typeNA = "MAR"; subtype = "L"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MAR"; subtype = "R"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MAR"; subtype = "LR"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MAR"; subtype = "C"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      
      # MNAR
      typeNA = "MNAR"; subtype = "L"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MNAR"; subtype = "R"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MNAR"; subtype = "LR"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MNAR"; subtype = "C"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all(tmp, cost_function, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all(tmp, cost_function, mode = 2), 3), sep = ", ")
      k = k+4
    }
  }
  return(prep_results(results, dep, N_iter))
}

# Result parser
prep_results <- function(RES, dep, N_iter)
{
  S1 = Reduce(rbind, strsplit(RES$score, ", "))[,-1]
  colnames(S1) = paste("S1", 1:ncol(S1), sep = "_")
  S2 = Reduce(rbind, strsplit(RES$score2, ", "))[,-1]
  colnames(S2) = paste("S2", 1:ncol(S2), sep = "_")
  res1 = cbind(RES[,1:3], S1)
  res.m1 = melt(res1, id.vars = c("model","typeNA", "pNA"))
  res.m1$variable = sapply(strsplit(as.vector(res.m1$variable), split = "_"), function(x) x[1])
  res.m1$value = as.numeric(res.m1$value)
  res2 = cbind(RES[,1:3], S2)
  res.m2 = melt(res2, id.vars = c("model","typeNA", "pNA"))
  res.m2$variable = sapply(strsplit(as.vector(res.m2$variable), split = "_"), function(x) x[1])
  res.m2$value = as.numeric(res.m2$value)
  return(list(res.m1 = res.m1, res.m2 = res.m2))
}

########################## Define Parameters ##########################

m = 10
p_h = 0.8
n = 200
R2 = 0.95
pNA = c(0.05, 0.1, 0.2, 0.3, 0.5, 0.7)
conditions = expand.grid(n, R2, pNA)
colnames(conditions) = c("n", "R2", "pNA")
mu = c(2, 1, 0.2, -2, 3, 0.1, 1.4, -2, 3, 0.001)
theta = c(0.7, -0.4, 2, 0.1, 0.5, -2, 0.5, 3, 0.8, -0.9, 0.01)
theta2 = c(0.7, +0.4, 10, 0.1, 0.5, 2, 0.5, 3, 0.8, -0.9, 0.01)
N_iter = 50

# Independent
sigma = c(1.42, 0.82, 1.22, 2.22, 1.67, 2, 0.71, 1.8, 0.73, 1.36)
Cov_ind = diag(sigma)

# Medium Dependence
Cov_wd = matrix(c(1.42, -0.16, 0.32, 0.49, 0.3, 0.11, 0.24, -0.64, 0.02, -0.8,
                  -0.16, 0.82, 0.28, -0.82, 0.3, -0.39, 0.23, -0.09, -0.24, -0.14,
                  0.32, 0.28, 1.22, -0.36, 0.78, 0.19, 0.46, -0.34, -0.2, 0.28,
                  0.49, -0.82, -0.36, 2.22, 0.27, 0.75, 0.33, 0.03, 0.31, -0.26,
                  0.3, 0.3, 0.78, 0.27, 1.67, 0.84, 0.44, 0.42, -0.17, -0.16,
                  0.11, -0.39, 0.19, 0.75, 0.84, 2, -0.03, 1.14, 0.03, -0.48,
                  0.24, 0.23, 0.46, 0.33, 0.44, -0.03, 0.71, -0.14, -0.06, -0.05,
                  -0.64, -0.09, -0.34, 0.03, 0.42, 1.14, -0.14, 1.8, -0.03, -0.31,
                  0.02, -0.24, -0.2, 0.31, -0.17, 0.03, -0.06, -0.03, 0.73, 0.09,
                  -0.8, -0.14, 0.28, -0.26, -0.16, -0.48, -0.05, -0.31, 0.09, 1.36),
                nrow = 10, byrow = T)

# Strong Dependence
Cov_sd = matrix(c(1.42, -0.06, 0.58, 0.36, 0.92, -0.12, 0.51, 0.61, -0.02, -0.02,
                  -0.06, 0.82, -0.15, -0.19, -0.09, 0.58, -0.13, -0.14, 0.01, -0.09,
                  0.58, -0.15, 1.22, 0.84, 1.03, -0.58, 0.79, 1.10, -0.05, 0.11,
                  0.36, -0.19, 0.84, 2.22, 0.99, -0.31, 0.73, 1.02, 0.01, 0.28,
                  0.92, -0.09, 1.03, 0.99, 1.67, -0.21, 0.96, 1.17, -0.15, 0.15,
                  -0.12, 0.58, -0.58, -0.31, -0.21, 2, -0.41, -0.42, -0.03, -0.19,
                  0.51, -0.13, 0.79, 0.73, 0.96, -0.41, 0.71, 0.91, -0.11, 0.13,
                  0.61, -0.14, 1.10, 1.02, 1.17, -0.42, 0.91, 1.8, -0.17, 0.06,
                  -0.02, 0.01, -0.05, 0.01, -0.15, -0.03, -0.11, -0.17, 0.73, -0.13,
                  -0.02, -0.09, 0.11, 0.28, 0.15, -0.19, 0.13, 0.06, -0.13, 1.36),
                nrow = 10, byrow = T)

# Ultra-strong dependence
Cov_usd = matrix(c(1.42, -0.8, -1.05, -0.85, -1.08, -0.9, -0.78, 1.43, 
                   0.75, -1.18, -0.8, 0.82, 0.51, 0.72, 0.65, 0.52, 0.54, -0.94, 
                   -0.49, 0.81, -1.05, 0.51, 1.22, 1.19, 1.02, 0.86, 0.82, -1.28, 
                   -0.78, 0.91, -0.85, 0.72, 1.19, 2.22, 1.21, 0.7, 1.06, -1.31, 
                   -0.86, 0.94, -1.08, 0.65, 1.02, 1.21, 1.67, 1.05, 0.74, -1.41, 
                   -0.61, 1.3, -0.9, 0.52, 0.86, 0.7, 1.05, 2, 0.56, -1.04, -0.6, 
                   1.04, -0.78, 0.54, 0.82, 1.06, 0.74, 0.56, 0.71, -1.03, -0.67, 
                   0.76, 1.43, -0.94, -1.28, -1.31, -1.41, -1.04, -1.03, 1.8, 1.01, 
                   -1.44, 0.75, -0.49, -0.78, -0.86, -0.61, -0.6, -0.67, 1.01, 0.73, 
                   -0.69, -1.18, 0.81, 0.91, 0.94, 1.3, 1.04, 0.76, -1.44, -0.69, 
                   1.36), nrow = 10)

############
############ (1) cor and bias
############

########################## Simulation 1: independent ##########################
start_time <- Sys.time()
set.seed(144)
out1 = simulation(mu, Cov_ind, theta, p_h, N_iter = N_iter, conditions, "independent", cor)
########################## Simulation 2: wd ##########################
set.seed(145)
out2 = simulation(mu, Cov_wd, theta, p_h, N_iter = N_iter, conditions, "wd", cor)
########################## Simulation 3: sd ##########################
set.seed(146)
out3 = simulation(mu, Cov_sd, theta, p_h, N_iter = N_iter, conditions, "sd", cor)
########################## Simulation 4: independent ##########################
set.seed(147)
out4 = simulation(mu, Cov_ind, theta2, p_h, N_iter = N_iter, conditions, "independent", cor)
########################## Simulation 5: wd ##########################
set.seed(148)
out5 = simulation(mu, Cov_wd, theta2, p_h, N_iter = N_iter, conditions, "wd", cor)
########################## Simulation 6: sd ##########################
set.seed(149)
out6 = simulation(mu, Cov_sd, theta2, p_h, N_iter = N_iter, conditions, "sd", cor)
end_time <- Sys.time()
end_time - start_time # Time difference of 2.66899 hours

# Export simulation results
out = list(out1 = out1,   out2 = out2,   out3 = out3, out4 = out4, out5 = out5, out6 = out6)
saveRDS(out, "round2.Rds")


########################## Additional simulation: usd ##########################
set.seed(150)
out7 = simulation(mu, Cov_usd, theta, p_h, N_iter = N_iter, conditions, "usd", cor)
saveRDS(out7, "round2_usd.Rds")


############
############ (2) concordance and bias
############

########################## Simulation 1: independent ##########################
start_time <- Sys.time()
set.seed(144)
out1 = simulation(mu, Cov_ind, theta, p_h, N_iter = N_iter, conditions, "independent", conc_cor)
########################## Simulation 2: wd ##########################
set.seed(145)
out2 = simulation(mu, Cov_wd, theta, p_h, N_iter = N_iter, conditions, "wd", conc_cor)
########################## Simulation 3: sd ##########################
set.seed(146)
out3 = simulation(mu, Cov_sd, theta, p_h, N_iter = N_iter, conditions, "sd", conc_cor)

# Export simulation results
out = list(out1 = out1, out2 = out2, out3 = out3)
saveRDS(out, "round2_concordance.Rds")


############
############ (3) MSE and bias
############

########################## Simulation 1: independent ##########################
start_time <- Sys.time()
set.seed(144)
out1 = simulation(mu, Cov_ind, theta, p_h, N_iter = N_iter, conditions, "independent", MSE)
########################## Simulation 2: wd ##########################
set.seed(145)
out2 = simulation(mu, Cov_wd, theta, p_h, N_iter = N_iter, conditions, "wd", MSE)
########################## Simulation 3: sd ##########################
set.seed(146)
out3 = simulation(mu, Cov_sd, theta, p_h, N_iter = N_iter, conditions, "sd", MSE)

# Export simulation results
out = list(out1 = out1, out2 = out2, out3 = out3)
saveRDS(out, "round2_MSE.Rds")




################################## Session Info ##################################

sessionInfo()
# R version 4.1.2 (2021-11-01)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: Ubuntu 18.04.5 LTS
# 
# Matrix products: default
# BLAS:   /usr/lib/x86_64-linux-gnu/blas/libblas.so.3.7.1
# LAPACK: /usr/lib/x86_64-linux-gnu/lapack/liblapack.so.3.7.1
# 
# locale:
# [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C               LC_TIME=nl_NL.UTF-8        LC_COLLATE=en_US.UTF-8    
# [5] LC_MONETARY=nl_NL.UTF-8    LC_MESSAGES=en_US.UTF-8    LC_PAPER=nl_NL.UTF-8       LC_NAME=C                 
# [9] LC_ADDRESS=C               LC_TELEPHONE=C             LC_MEASUREMENT=nl_NL.UTF-8 LC_IDENTIFICATION=C       
# 
# attached base packages:
# [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
# [1] fastmatrix_0.3-8196 Matrix_1.3-4        reshape_0.8.8       ggplot2_3.3.5       matrixStats_0.61.0 
# [6] gtools_3.9.2        mice_3.13.0         gplots_3.1.1        MASS_7.3-54         matrixcalc_1.0-5   
# 
# loaded via a namespace (and not attached):
# [1] backports_1.3.0             BiocFileCache_2.0.0         plyr_1.8.6                  splines_4.1.2              
# [5] BiocParallel_1.26.2         GenomeInfoDb_1.28.4         digest_0.6.28               foreach_1.5.1              
# [9] fansi_0.5.0                 magrittr_2.0.1              memoise_2.0.0               tzdb_0.2.0                 
# [13] limma_3.48.3                Biostrings_2.60.2           readr_2.1.0                 annotate_1.70.0            
# [17] askpass_1.1                 siggenes_1.66.0             prettyunits_1.1.1           colorspace_2.0-2           
# [21] blob_1.2.2                  rappdirs_0.3.3              dplyr_1.0.7                 crayon_1.4.2               
# [25] RCurl_1.98-1.5              genefilter_1.74.1           lme4_1.1-27.1               GEOquery_2.60.0            
# [29] survival_3.2-13             iterators_1.0.13            glue_1.5.0                  gtable_0.3.0               
# [33] zlibbioc_1.38.0             XVector_0.32.0              DelayedArray_0.18.0         Rhdf5lib_1.14.2            
# [37] BiocGenerics_0.38.0         HDF5Array_1.20.0            scales_1.1.1                jomo_2.7-2                 
# [41] abind_1.4-5                 mvtnorm_1.1-3               DBI_1.1.1                   rngtools_1.5.2             
# [45] Rcpp_1.0.7                  xtable_1.8-4                progress_1.2.2              bumphunter_1.34.0          
# [49] bit_4.0.4                   mclust_5.4.8                preprocessCore_1.54.0       stats4_4.1.2               
# [53] httr_1.4.2                  RColorBrewer_1.1-2          ellipsis_0.3.2              farver_2.1.0               
# [57] pkgconfig_2.0.3             XML_3.99-0.8                dbplyr_2.1.1                locfit_1.5-9.4             
# [61] utf8_1.2.2                  labeling_0.4.2              tidyselect_1.1.1            rlang_0.4.12               
# [65] AnnotationDbi_1.54.1        munsell_0.5.0               tools_4.1.2                 cachem_1.0.6               
# [69] generics_0.1.1              RSQLite_2.2.8               broom_0.7.10                stringr_1.4.0              
# [73] mvmeta_1.0.3                fastmap_1.1.0               yaml_2.2.1                  bit64_4.0.5                
# [77] beanplot_1.2                caTools_1.18.2              scrime_1.3.5                purrr_0.3.4                
# [81] KEGGREST_1.32.0             nlme_3.1-153                doRNG_1.8.2                 sparseMatrixStats_1.4.2    
# [85] nor1mix_1.3-0               xml2_1.3.2                  biomaRt_2.48.3              compiler_4.1.2             
# [89] rstudioapi_0.13             filelock_1.0.2              curl_4.3.2                  png_0.1-7                  
# [93] tibble_3.1.6                stringi_1.7.5               GenomicFeatures_1.44.2      minfi_1.38.0               
# [97] lattice_0.20-45             nloptr_1.2.2.3              multtest_2.48.0             vctrs_0.3.8                
# [101] pillar_1.6.4                lifecycle_1.0.1             rhdf5filters_1.4.0          data.table_1.14.2          
# [105] bitops_1.0-7                micemd_1.8.0                rtracklayer_1.52.1          mixmeta_1.2.0              
# [109] GenomicRanges_1.44.0        R6_2.5.1                    BiocIO_1.2.0                KernSmooth_2.23-20         
# [113] IRanges_2.26.0              codetools_0.2-18            boot_1.3-28                 assertthat_0.2.1           
# [117] rhdf5_2.36.0                SummarizedExperiment_1.22.0 openssl_1.4.5               rjson_0.2.20               
# [121] withr_2.4.2                 GenomicAlignments_1.28.0    Rsamtools_2.8.0             S4Vectors_0.30.2           
# [125] GenomeInfoDbData_1.2.6      mgcv_1.8-38                 parallel_4.1.2              hms_1.1.1                  
# [129] quadprog_1.5-8              grid_4.1.2                  tidyr_1.1.4                 base64_2.0                 
# [133] minqa_1.2.4                 DelayedMatrixStats_1.14.3   illuminaio_0.34.0           MatrixGenerics_1.4.3       
# [137] Biobase_2.52.0              restfulr_0.0.13    
