############################################################################
############################################################################
###########                                                      ###########
###########          Simulation study, round 3 (aps-lm)          ###########
###########             Author: Benjamin Planterose              ###########
###########                                                      ###########
###########        Erasmus MC University Medical Centre          ###########
###########               Rotterdam, The Netherlands             ###########
###########                                                      ###########
###########              b.planterosejimenez@gmail.com           ###########
###########                                                      ###########
############################################################################
############################################################################

# Load libraries
library(matrixcalc)
library(MASS)
library(gplots)
library(gtools)
library(matrixStats)
library(ggplot2)
library(reshape)
library(Matrix)
library(fastmatrix)
library(glmnet)

# Load functions
# Common functions
source("common_functions.R")

# Global simulation wrapper
simulation <- function(mu, Cov, theta, p_h, N_iter, conditions, dep)
{
  
  results <- expand.grid(c("ols", "ridge", "ad-lm_ols", "ad-ridge-lambda"), 
                         c("MCAR", "MAR_L", "MAR_R", "MAR_LR", "MAR_C", "MNAR_L", "MNAR_R","MNAR_LR", "MNAR_C"),
                         conditions$pNA) # Assumes n and R^2 are constant
  colnames(results) = c("model", "typeNA", "pNA")
  results$score = ""
  results$score2 = ""
  
  for(i in 1:nrow(conditions))
  {
    pNA = conditions[i,"pNA"]
    print(paste(i, "out of", nrow(conditions)))
    for(l in 1:N_iter)
    {
      k = min(which(results$pNA == pNA))
      # 1. Data generation
      data = data_generation(n = n, mu = mu, Cov = Cov, theta = theta, R2 = R2)
      
      # 2. Splitting
      data = split(data = data, p_h = p_h, n = n)
      
      # 3. N/A injection
      # MCAR
      typeNA = "MCAR"; subtype = NULL
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      
      # MAR
      typeNA = "MAR"; subtype = "L"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MAR"; subtype = "R"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MAR"; subtype = "LR"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MAR"; subtype = "C"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      
      # MNAR
      typeNA = "MNAR"; subtype = "L"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MNAR"; subtype = "R"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MNAR"; subtype = "LR"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
      typeNA = "MNAR"; subtype = "C"
      tmp = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
      results[k:(k+3), 4] = paste(results[k:(k+3), 4], round(test_all2(tmp, MSE, mode = 1), 3), sep = ", ")
      results[k:(k+3), 5] = paste(results[k:(k+3), 5], round(test_all2(tmp, MSE, mode = 2), 3), sep = ", ")
      k = k+4
    }
  }
  return(prep_results(results, dep, N_iter))
}

# Test performance of full (ols), full (ridge), aps-lm and aps-ridge
test_all2 <- function(data, cost_function, mode)
{
  c(test_full(data, cost_function, mode), # ols
    test_ridge(data, cost_function, mode), # ridge
    test_cmb_lm(data, cost_function, mode), # aps-lm
    test_aps_ridge(data, cost_function, mode)) # aps-ridge
}

# Test performance of full (ridge)
test_ridge <- function(data, cost_function, mode)
{
  # # find lambda optim
  # # glmnet can be confusing to interpret coefficients as it standarizes y and transforms lambda.
  # # But it has a very efficient implementation of CV. So it is worth employing and translating.
  # # penalized
  # data = simulate_data(n, mu, Cov_wd, theta, R2, p_h, pNA[3], "MCAR", NULL)
  # lambda = 100
  # reg_mod2 = penalized(penalized = data$ref$X, response = data$ref$y, lambda1 = 0, lambda2 = lambda)
  # # glmnet
  # reg_mod1 = glmnet(x = data$ref$X, y = data$ref$y, alpha = 0, standardize = F, intercept = T, thresh = 1e-20)
  # n = nrow(data$ref$X); sd_y <- sqrt(var(data$ref$y)*(n-1)/n)
  # cofs = as.vector(coef(x = data$ref$X, y = data$ref$y, reg_mod1, s = sd_y*lambda/n, exact = TRUE))
  # plot(cofs, coef(reg_mod2)); abline(0, 1, lty = 2)
  
  # Cross-validation
  reg_mod1 = cv.glmnet(x = data$ref$X, y = data$ref$y, alpha = 0, 
                       standardize = F, intercept = T, thresh = 1e-20, nfolds = 5)
  lambda.min = reg_mod1$lambda.min
  theta_ridge = as.vector(coef(x = data$ref$X, y = data$ref$y, reg_mod1, s = lambda.min, exact = TRUE))
  metric(cbind(1, data$app0$X) %*% theta_ridge, data$app0$y, cost_function, mode)
}

# Perform 5-fold CV to estimate optimal lambda in ridge regression
CV_lambda = function(X, y)
{
  CV = cv.glmnet(x = X, y = y, alpha = 0, 
                 standardize = F, intercept = T, thresh = 1e-20, nfolds = 5)
  n = nrow(X); sd_y = sqrt(var(y)*(n-1)/n)
  CV$lambda.min*n/sd_y
}

# Test performance of aps-ridge
test_aps_ridge <- function(data, cost_function, mode)
{
  # Find lambda by CV
  reg_mod1 = cv.glmnet(x = data$ref$X, y = data$ref$y, alpha = 0, 
                       standardize = F, intercept = T, thresh = 1e-20, nfolds = 5)
  lambda.min = reg_mod1$lambda.min
  theta = as.vector(coef(x = data$ref$X, y = data$ref$y, reg_mod1, s = lambda.min, exact = TRUE))
  n = nrow(data$ref$X); sd_y = sqrt(var(data$ref$y)*(n-1)/n)
  lambda = lambda.min*n/sd_y
  
  # Determine cmb-ridge parameters
  m = length(theta)-1
  Iridge = diag(m+1); Iridge[1,1] = 0
  R = chol(t(cbind(1, data$ref$X)) %*% cbind(1, data$ref$X) + lambda*Iridge)
  yty = t(data$ref$y) %*% data$ref$y
  XtX = rbind(cbind(t(R) %*% R, t(R) %*% R %*% theta), c(t(R) %*% R %*% theta, yty))
  
  X_ = cbind(1, data$app$X)
  Indicator = is.na(X_)
  omegaC_list = lapply(1:nrow(Indicator), function(x) (1:(m+1))[!(1:(m+1) %in% which(Indicator[x,]))])
  y_pred = sapply(1:nrow(X_), function(x) na.omit(X_[x,]) %*% theta_omega(XtX, omegaC_list[[x]]))
  metric(y_pred, data$app0$y, cost_function, mode)
}

# Metrics (correlation, bias)
metric <- function(pred, obs, cost_function, mode)
{
  if(mode == 1) # metric
  {
    return(cost_function(pred, obs))
  }
  else if(mode == 2) # bias
  {
    return(mean(pred-obs))
  }
}

# Result parser
prep_results <- function(RES, dep, N_iter)
{
  S1 = Reduce(rbind, strsplit(RES$score, ", "))[,-1]
  colnames(S1) = paste("S1", 1:ncol(S1), sep = "_")
  S2 = Reduce(rbind, strsplit(RES$score2, ", "))[,-1]
  colnames(S2) = paste("S2", 1:ncol(S2), sep = "_")
  res1 = cbind(RES[,1:3], S1)
  res.m1 = melt(res1, id.vars = c("model","typeNA", "pNA"))
  res.m1$variable = sapply(strsplit(as.vector(res.m1$variable), split = "_"), function(x) x[1])
  res.m1$value = as.numeric(res.m1$value)
  res2 = cbind(RES[,1:3], S2)
  res.m2 = melt(res2, id.vars = c("model","typeNA", "pNA"))
  res.m2$variable = sapply(strsplit(as.vector(res.m2$variable), split = "_"), function(x) x[1])
  res.m2$value = as.numeric(res.m2$value)
  return(list(res.m1 = res.m1, res.m2 = res.m2))
}

########################## Define Parameters ##########################

m = 10
p_h = 0.8
n = 200
R2 = 0.95
pNA = c(0.05, 0.1, 0.2, 0.3, 0.5, 0.7)
conditions = expand.grid(n, R2, pNA)
colnames(conditions) = c("n", "R2", "pNA")
mu = c(2, 1, 0.2, -2, 3, 0.1, 1.4, -2, 3, 0.001)
theta = c(0.7, -0.4, 2, 0.1, 0.5, -2, 0.5, 3, 0.8, -0.9, 0.01)
N_iter = 50

# Independent
sigma = c(1.42, 0.82, 1.22, 2.22, 1.67, 2, 0.71, 1.8, 0.73, 1.36)
Cov_ind = diag(sigma)

# Medium Dependency
Cov_wd = matrix(c(1.42, -0.16, 0.32, 0.49, 0.3, 0.11, 0.24, -0.64, 0.02, -0.8,
                  -0.16, 0.82, 0.28, -0.82, 0.3, -0.39, 0.23, -0.09, -0.24, -0.14,
                  0.32, 0.28, 1.22, -0.36, 0.78, 0.19, 0.46, -0.34, -0.2, 0.28,
                  0.49, -0.82, -0.36, 2.22, 0.27, 0.75, 0.33, 0.03, 0.31, -0.26,
                  0.3, 0.3, 0.78, 0.27, 1.67, 0.84, 0.44, 0.42, -0.17, -0.16,
                  0.11, -0.39, 0.19, 0.75, 0.84, 2, -0.03, 1.14, 0.03, -0.48,
                  0.24, 0.23, 0.46, 0.33, 0.44, -0.03, 0.71, -0.14, -0.06, -0.05,
                  -0.64, -0.09, -0.34, 0.03, 0.42, 1.14, -0.14, 1.8, -0.03, -0.31,
                  0.02, -0.24, -0.2, 0.31, -0.17, 0.03, -0.06, -0.03, 0.73, 0.09,
                  -0.8, -0.14, 0.28, -0.26, -0.16, -0.48, -0.05, -0.31, 0.09, 1.36),
                nrow = 10, byrow = T)

# Strong Dependency
Cov_sd = matrix(c(1.42, -0.06, 0.58, 0.36, 0.92, -0.12, 0.51, 0.61, -0.02, -0.02,
                  -0.06, 0.82, -0.15, -0.19, -0.09, 0.58, -0.13, -0.14, 0.01, -0.09,
                  0.58, -0.15, 1.22, 0.84, 1.03, -0.58, 0.79, 1.10, -0.05, 0.11,
                  0.36, -0.19, 0.84, 2.22, 0.99, -0.31, 0.73, 1.02, 0.01, 0.28,
                  0.92, -0.09, 1.03, 0.99, 1.67, -0.21, 0.96, 1.17, -0.15, 0.15,
                  -0.12, 0.58, -0.58, -0.31, -0.21, 2, -0.41, -0.42, -0.03, -0.19,
                  0.51, -0.13, 0.79, 0.73, 0.96, -0.41, 0.71, 0.91, -0.11, 0.13,
                  0.61, -0.14, 1.10, 1.02, 1.17, -0.42, 0.91, 1.8, -0.17, 0.06,
                  -0.02, 0.01, -0.05, 0.01, -0.15, -0.03, -0.11, -0.17, 0.73, -0.13,
                  -0.02, -0.09, 0.11, 0.28, 0.15, -0.19, 0.13, 0.06, -0.13, 1.36),
                nrow = 10, byrow = T)

########################## Simulation 1: independent ##########################
start_time <- Sys.time()
set.seed(144)
out1 = simulation(mu, Cov_ind, theta, p_h, N_iter = N_iter, conditions, "independent")
########################## Simulation 2: wd ##########################
set.seed(145)
out2 = simulation(mu, Cov_wd, theta, p_h, N_iter = N_iter, conditions, "wd")
########################## Simulation 3: sd ##########################
set.seed(146)
out3 = simulation(mu, Cov_sd, theta, p_h, N_iter = N_iter, conditions, "sd")
end_time <- Sys.time()
end_time - start_time # Time difference of 18.85497 mins

################################## Save results ##################################

RES = list(out1 = out1, out2 = out2, out3 = out3)
saveRDS(RES, file = "round3.Rds")

################################## Session Info ##################################

sessionInfo()
# R version 4.1.2 (2021-11-01)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: Ubuntu 18.04.6 LTS
# 
# Matrix products: default
# BLAS:   /usr/lib/x86_64-linux-gnu/blas/libblas.so.3.7.1
# LAPACK: /usr/lib/x86_64-linux-gnu/lapack/liblapack.so.3.7.1
# 
# locale:
# [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C               LC_TIME=nl_NL.UTF-8       
# [4] LC_COLLATE=en_US.UTF-8     LC_MONETARY=nl_NL.UTF-8    LC_MESSAGES=en_US.UTF-8   
# [7] LC_PAPER=nl_NL.UTF-8       LC_NAME=C                  LC_ADDRESS=C              
# [10] LC_TELEPHONE=C             LC_MEASUREMENT=nl_NL.UTF-8 LC_IDENTIFICATION=C       
# 
# attached base packages:
# [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
# [1] glmnet_4.1-8      fastmatrix_0.5    Matrix_1.6-0      reshape_0.8.9     ggplot2_3.4.3    
# [6] matrixStats_1.0.0 gtools_3.9.4      mice_3.16.0       gplots_3.1.3      MASS_7.3-54      
# [11] matrixcalc_1.0-6 
# 
# loaded via a namespace (and not attached):
# [1] mitml_0.4-5        Rcpp_1.0.11        mvtnorm_1.2-3      lattice_0.21-8     tidyr_1.3.0       
# [6] class_7.3-20       foreach_1.5.2      utf8_1.2.3         plyr_1.8.8         R6_2.5.1          
# [11] cellranger_1.1.0   pan_1.9            backports_1.4.1    jomo_2.7-6         rootSolve_1.8.2.4 
# [16] e1071_1.7-13       httr_1.4.7         pillar_1.9.0       rlang_1.1.1        Exact_3.2         
# [21] readxl_1.4.3       rstudioapi_0.15.0  minqa_1.2.6        data.table_1.14.8  nloptr_2.0.3      
# [26] rpart_4.1.19       splines_4.1.2      lme4_1.1-34        munsell_0.5.0      proxy_0.4-27      
# [31] broom_1.0.5        compiler_4.1.2     pkgconfig_2.0.3    shape_1.4.6        DescTools_0.99.50 
# [36] nnet_7.3-17        tidyselect_1.2.0   tibble_3.2.1       lmom_3.0           expm_0.999-7      
# [41] codetools_0.2-19   fansi_1.0.4        dplyr_1.1.3        withr_2.5.0        bitops_1.0-7      
# [46] grid_4.1.2         nlme_3.1-162       gtable_0.3.4       lifecycle_1.0.3    magrittr_2.0.3    
# [51] scales_1.2.1       gld_2.6.6          KernSmooth_2.23-22 cli_3.6.1          generics_0.1.3    
# [56] vctrs_0.6.3        boot_1.3-28        iterators_1.0.14   tools_4.1.2        glue_1.6.2        
# [61] purrr_1.0.2        survival_3.5-5     colorspace_2.1-0   caTools_1.18.2