############################################################################
############################################################################
###########                                                      ###########
###########          Simulation study, round 4 (aps-lm)          ###########
###########             Author: Benjamin Planterose              ###########
###########                                                      ###########
###########        Erasmus MC University Medical Centre          ###########
###########               Rotterdam, The Netherlands             ###########
###########                                                      ###########
###########              b.planterosejimenez@gmail.com           ###########
###########                                                      ###########
############################################################################
############################################################################

library(MASS)
library(reshape)
library(ggplot2)
library(fastmatrix)

# Global simulation wrapper
simulation <- function(mu, Cov, theta, N_cov, conditions, omega_list, N_rep, confidence = 0.95)
{
  cov = matrix(0, ncol = 2, nrow = nrow(conditions))
  colnames(cov) = paste("cov", c("ci", "pi"), sep = ":")
  conditions = cbind(cov, conditions)
  
  for(i in 1:nrow(conditions))
  {
    print(paste(i, "out of", nrow(conditions)))
    res = matrix(ncol = 2, nrow = N_rep)
    for(l in 1:N_rep)
    {
      x0 = MASS::mvrnorm(1, mu, Cov)
      out = coverage(n = conditions[i,]$n, mu = mu, Cov = Cov, theta = theta, 
                     R2 = conditions[i,]$R2, omega = omega_list[[conditions[i,]$omega]], N_cov = N_cov,
                     x0 = x0, confidence = confidence)
      res[l,] = out
      if(sum(is.na(out)) > 0)
      {
        print(conditions[i,])
      }
    }
    conditions[i, 1] = paste(res[,1], collapse = ", ")
    conditions[i, 2] = paste(res[,2], collapse = ", ")
  }
  return(prep_results(conditions))
}

# Estimate conf/pred interval coverage across N_cov iterations
coverage <- function(n, mu, Cov, theta, R2, omega, N_cov, x0, confidence)
{
  m = nrow(Cov)
  dim(x0) = c(1, m)
  ind_in = lapply(1:N_cov, function(i) iteration(n, mu, Cov, theta, R2, omega, N_cov, 
                                                 x0, confidence))
  return(c(ci = mean(sapply(ind_in, function(x) x$ci)),
           pi = mean(sapply(ind_in, function(x) x$pi))))
}

# Check whether y,E[y|x] for an iteration falls within estimated conf/pred intervals
iteration <- function(n, mu, Cov, theta, R2, omega, N_cov, x0, confidence)
{
  # Generate X
  X = MASS::mvrnorm(n, mu, Cov)
  
  # Generate y
  mu = c(1, mu)
  Cov = rbind(0, cbind(0, Cov))
  R = chol(n*Cov + n*mu %*% t(mu))
  var_y_tilde_emptyset = t(theta) %*% Cov %*% theta
  sigma_epsilon_emptyset = sqrt((1-R2)/R2*var_y_tilde_emptyset)
  y_tilde_emptyset = cbind(1, X) %*% theta
  y = y_tilde_emptyset + rnorm(n, mean = 0, sd = sigma_epsilon_emptyset)
  var_y = var_y_tilde_emptyset + sigma_epsilon_emptyset^2
  
  # Compute submodel params
  m = ncol(Cov)-1 # -1 because (intercept) column/row was added before
  omega_c = (1:(m+1))[!(1:(m+1) %in% (omega+1))]
  theta_omega = MASS::ginv(R[,omega_c]) %*% R %*% theta
  var_y_tilde_omega = t(theta_omega) %*% Cov[omega_c, omega_c] %*% theta_omega
  y_tilde_omega = as.numeric(cbind(1, X)[,omega_c] %*% theta_omega)
  R2_Omega = var_y_tilde_omega/var_y
  sigma_epsilon_omega = sqrt((1-R2_Omega)/R2_Omega*var_y_tilde_omega)
  
  # Compute real values for x0
  y0_hat = as.numeric(c(1, x0)[omega_c] %*% theta_omega)
  y0 = y0_hat + rnorm(1, mean = 0, sd = sigma_epsilon_omega)
  
  # Compute confidence/prediction intervals
  X_ = cbind(cbind(1, X), y)
  #XtX = t(X_) %*% X_
  XtX = crossprod(X_)
  x0 = c(1, x0) # add intercept
  x0[omega+1] = NA # Remove unavailable variables
  ci = conf.int(x0[omega_c], XtX, omega_c, 1-confidence)
  pi = pred.int(x0[omega_c], XtX, omega_c, 1-confidence)
  list(ci = sum((y0_hat > ci["lwr"]) & (y0_hat < ci["upr"])),
       pi = sum((y0 > pi["lwr"]) & (y0 < pi["upr"])))
  #### Same interval computed with linear submodels
  # df = as.data.frame(model.matrix(~ X))[,omega_c]
  # df$y = y
  # mod1 = lm(y ~ 0+., data = df)
  # options(na.action = "na.pass")
  # df2 = as.data.frame(model.matrix(~ t(x0[-1])))[,omega_c]
  # colnames(df2) = colnames(df)[-ncol(df)]
  # predict(mod1, newdata = df2, interval = "prediction")
  # predict(mod1, newdata = df2, interval = "confidence")
}

# Estimate confidence interval
conf.int = function(x, XtX, omega_c, alpha)
{
  dim(x) = c(1, length(omega_c))
  n = XtX[1,1]
  m = nrow(XtX)-2
  #S_X = fastmatrix::sweep.operator(XtX, k = omega_c)
  S_X = sweep.operator(XtX, k = omega_c)
  theta_omega = S_X[omega_c, m+2]
  sigma2_epsilon = S_X[m+2, m+2]/(n-length(omega_c))
  fit = x %*% theta_omega
  add = qt(p = 1-alpha/2, df = n-length(omega_c))*sqrt(sigma2_epsilon)*sqrt(x %*% MASS::ginv(XtX[omega_c, omega_c]) %*% t(x))
  c(fit = fit, lwr = fit - add, upr = fit + add)
}

# Estimate prediction interval
pred.int = function(x, XtX, omega_c, alpha)
{
  dim(x) = c(1, length(omega_c))
  n = XtX[1,1]
  m = nrow(XtX)-2
  #S_X = fastmatrix::sweep.operator(XtX, k = omega_c)
  S_X = sweep.operator(XtX, k = omega_c)
  theta_omega = S_X[omega_c, m+2]
  sigma2_epsilon = S_X[m+2, m+2]/(n-length(omega_c))
  fit = x %*% theta_omega
  add = qt(p = 1-alpha/2, df = n-length(omega_c))*sqrt(sigma2_epsilon)*sqrt(x %*% MASS::ginv(XtX[omega_c, omega_c]) %*% t(x)+1)
  c(fit = fit, lwr = fit - add, upr = fit + add)
}

# Result parser
prep_results <- function(RES)
{
  CI = Reduce(rbind, strsplit(RES$`cov:ci`, ", "))
  colnames(CI) = paste("CI", 1:ncol(CI), sep = "_")
  PI = Reduce(rbind, strsplit(RES$`cov:pi`, ", "))
  colnames(PI) = paste("PI", 1:ncol(PI), sep = "_")
  res = Reduce(cbind, list(RES[,-(1:2)], CI, PI))
  res.m = melt(res, id.vars = c("n","R2", "omega"))
  res.m$value = as.numeric(res.m$value)
  res.m$variable = sapply(strsplit(as.vector(res.m$variable), "_"), function(x) x[1])
  return(res.m)
}

##### Taken from https://github.com/faosorios/fastmatrix/blob/master/pkg/R/sweep.R
# We have removed the symmetry checking conditional 
sweep.operator <- function(x, k = 1, reverse = FALSE)
{ ## Gauss-Jordan sweep operator for symmetric matrices
  if (is.data.frame(x))
    x <- as.matrix(x)
  if (!is.matrix(x))
    stop("supply a matrix-like 'x'")
  if (!is.numeric(x))
    stop("argument x is not a numeric matrix" )
  
  dx <- dim(x)
  n <- dx[1]
  p <- dx[2]
  if (n != p)
    stop("argument x is not a square matrix")
  # if (!isSymmetric(unname(x)))         #### REMOVE symmetry check step
  #   stop("only implemented for symmetric matrices.")
  k <- as.vector(k)
  r <- length(k)
  
  storage.mode(x) <- "double"
  z <- .C("sweep_operator",
          x = x,
          ldx = as.integer(n),
          p = as.integer(p),
          k = as.integer(k),
          r = as.integer(r),
          reverse = as.integer(reverse))$x
  z
}
#####
# Check that sweep_operator.c has been loaded
routines_c = getDLLRegisteredRoutines("fastmatrix")$.C
sum(names(routines_c) == "sweep_operator") # 1


########################## Define Parameters ##########################

m = 10
mu = c(2, 1, 0.2, -2, 3, 0.1, 1.4, -2, 3, 0.001)
theta = c(0.7, -0.4, 2, 0.1, 0.5, -2, 0.5, 3, 0.8, -0.9, 0.01)

# Independent
sigma = c(1.42, 0.82, 1.22, 2.22, 1.67, 2, 0.71, 1.8, 0.73, 1.36)
Cov_ind = diag(sigma)
# Medium Dependency
Cov_wd = matrix(c(1.42, -0.16, 0.32, 0.49, 0.3, 0.11, 0.24, -0.64, 0.02, -0.8,
                  -0.16, 0.82, 0.28, -0.82, 0.3, -0.39, 0.23, -0.09, -0.24, -0.14,
                  0.32, 0.28, 1.22, -0.36, 0.78, 0.19, 0.46, -0.34, -0.2, 0.28,
                  0.49, -0.82, -0.36, 2.22, 0.27, 0.75, 0.33, 0.03, 0.31, -0.26,
                  0.3, 0.3, 0.78, 0.27, 1.67, 0.84, 0.44, 0.42, -0.17, -0.16,
                  0.11, -0.39, 0.19, 0.75, 0.84, 2, -0.03, 1.14, 0.03, -0.48,
                  0.24, 0.23, 0.46, 0.33, 0.44, -0.03, 0.71, -0.14, -0.06, -0.05,
                  -0.64, -0.09, -0.34, 0.03, 0.42, 1.14, -0.14, 1.8, -0.03, -0.31,
                  0.02, -0.24, -0.2, 0.31, -0.17, 0.03, -0.06, -0.03, 0.73, 0.09,
                  -0.8, -0.14, 0.28, -0.26, -0.16, -0.48, -0.05, -0.31, 0.09, 1.36),
                nrow = 10, byrow = T)
# Strong Dependency
Cov_sd = matrix(c(1.42, -0.06, 0.58, 0.36, 0.92, -0.12, 0.51, 0.61, -0.02, -0.02,
                  -0.06, 0.82, -0.15, -0.19, -0.09, 0.58, -0.13, -0.14, 0.01, -0.09,
                  0.58, -0.15, 1.22, 0.84, 1.03, -0.58, 0.79, 1.10, -0.05, 0.11,
                  0.36, -0.19, 0.84, 2.22, 0.99, -0.31, 0.73, 1.02, 0.01, 0.28,
                  0.92, -0.09, 1.03, 0.99, 1.67, -0.21, 0.96, 1.17, -0.15, 0.15,
                  -0.12, 0.58, -0.58, -0.31, -0.21, 2, -0.41, -0.42, -0.03, -0.19,
                  0.51, -0.13, 0.79, 0.73, 0.96, -0.41, 0.71, 0.91, -0.11, 0.13,
                  0.61, -0.14, 1.10, 1.02, 1.17, -0.42, 0.91, 1.8, -0.17, 0.06,
                  -0.02, 0.01, -0.05, 0.01, -0.15, -0.03, -0.11, -0.17, 0.73, -0.13,
                  -0.02, -0.09, 0.11, 0.28, 0.15, -0.19, 0.13, 0.06, -0.13, 1.36),
                nrow = 10, byrow = T)

N_cov = 1000
N_rep = 20
m = 10
n = c(50, 100, 200)
R2 = c(0.25, 0.5, 0.95)
omega_list = list(omega0 = c(), omega1 = c(2), omega2 = c(2,4,7), omega3 = c(1,2,3,4,8,9))
conditions = expand.grid(n, R2, c("omega0", "omega1", "omega2", "omega3"))
colnames(conditions) = c("n", "R2", "omega")
confidence = 0.95

########################## Simulation 1: independence ##########################
start_time <- Sys.time()
set.seed(150)
res.m1 = simulation(mu = mu, Cov = Cov_ind, theta =  theta, N_cov =  N_cov, 
                    conditions = conditions, omega_list = omega_list, N_rep = N_rep, 
                    confidence = confidence)
########################## Simulation 2: wd ##########################
set.seed(151)
res.m2 = simulation(mu = mu, Cov = Cov_wd, theta =  theta, N_cov =  N_cov, 
                   conditions = conditions, omega_list = omega_list, N_rep = N_rep, 
                   confidence = confidence)
########################## Simulation 3: sd ##########################
set.seed(152)
res.m3 = simulation(mu = mu, Cov = Cov_sd, theta =  theta, N_cov =  N_cov, 
                    conditions = conditions, omega_list = omega_list, N_rep = N_rep, 
                    confidence = confidence)
end_time <- Sys.time()
end_time - start_time # Time difference of 35.95185 mins

################################## Save results ##################################

RES = list(res.m1 = res.m1, res.m2 = res.m2, res.m3 = res.m3)
saveRDS(RES, file = "round4.Rds")

################################## Session Info ##################################

sessionInfo()
# R version 4.1.2 (2021-11-01)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: Ubuntu 18.04.6 LTS
# 
# Matrix products: default
# BLAS:   /usr/lib/x86_64-linux-gnu/blas/libblas.so.3.7.1
# LAPACK: /usr/lib/x86_64-linux-gnu/lapack/liblapack.so.3.7.1
# 
# locale:
# [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C               LC_TIME=nl_NL.UTF-8       
# [4] LC_COLLATE=en_US.UTF-8     LC_MONETARY=nl_NL.UTF-8    LC_MESSAGES=en_US.UTF-8   
# [7] LC_PAPER=nl_NL.UTF-8       LC_NAME=C                  LC_ADDRESS=C              
# [10] LC_TELEPHONE=C             LC_MEASUREMENT=nl_NL.UTF-8 LC_IDENTIFICATION=C       
# 
# attached base packages:
# [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
# [1] ggplot2_3.4.3 reshape_0.8.9 MASS_7.3-54  
# 
# loaded via a namespace (and not attached):
# [1] Rcpp_1.0.11       rstudioapi_0.15.0 magrittr_2.0.3    splines_4.1.2    
# [5] tidyselect_1.2.0  munsell_0.5.0     lattice_0.21-8    colorspace_2.1-0 
# [9] R6_2.5.1          rlang_1.1.1       fansi_1.0.4       plyr_1.8.8       
# [13] dplyr_1.1.3       tools_4.1.2       grid_4.1.2        nlme_3.1-162     
# [17] gtable_0.3.4      mgcv_1.9-0        utf8_1.2.3        cli_3.6.1        
# [21] withr_2.5.0       tibble_3.2.1      lifecycle_1.0.3   Matrix_1.6-0     
# [25] fastmatrix_0.5    farver_2.1.1      vctrs_0.6.3       glue_1.6.2       
# [29] labeling_0.4.3    compiler_4.1.2    pillar_1.9.0      generics_0.1.3   
# [33] scales_1.2.1      pkgconfig_2.0.3  

###########  Tested also on:
# R version 4.4.0 (2024-04-24)
# Platform: x86_64-pc-linux-gnu
# Running under: Ubuntu 18.04.6 LTS
# 
# Matrix products: default
# BLAS:   /usr/lib/x86_64-linux-gnu/openblas/libblas.so.3 
# LAPACK: /usr/lib/x86_64-linux-gnu/libopenblasp-r0.2.20.so;  LAPACK version 3.7.1
# 
# locale:
# [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C               LC_TIME=nl_NL.UTF-8       
# [4] LC_COLLATE=en_US.UTF-8     LC_MONETARY=nl_NL.UTF-8    LC_MESSAGES=en_US.UTF-8   
# [7] LC_PAPER=nl_NL.UTF-8       LC_NAME=C                  LC_ADDRESS=C              
# [10] LC_TELEPHONE=C             LC_MEASUREMENT=nl_NL.UTF-8 LC_IDENTIFICATION=C       
# 
# time zone: Europe/Amsterdam
# tzcode source: system (glibc)
# 
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#   [1] fastmatrix_0.5-772 ggplot2_3.5.1      reshape_0.8.9      MASS_7.3-60       
# 
# loaded via a namespace (and not attached):
# [1] utf8_1.2.4       R6_2.5.1         magrittr_2.0.3   gtable_0.3.5     glue_1.7.0      
# [6] tibble_3.2.1     pkgconfig_2.0.3  lifecycle_1.0.4  cli_3.6.2        fansi_1.0.6     
# [11] scales_1.3.0     grid_4.4.0       vctrs_0.6.5      withr_3.0.0      compiler_4.4.0  
# [16] plyr_1.8.9       tools_4.4.0      pillar_1.9.0     munsell_0.5.1    Rcpp_1.0.12     
# [21] colorspace_2.1-0 rlang_1.1.3     

