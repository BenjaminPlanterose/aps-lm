# Global data generation wrapper
simulate_data <- function(n, mu, Cov, theta, R2, p_h, pNA, typeNA, subtype)
{
  # 1. Data generation
  data = data_generation(n = n, mu = mu, Cov = Cov, theta = theta, R2 = R2)
  
  # 2. Splitting
  data = split(data = data, p_h = p_h, n = n)
  
  # 3. N/A injection
  data = inject.NA(data = data, p = pNA, type = typeNA, subtype = subtype)
  return(data)
}

# Multivariate normal distributed data generation + linearly dependent variable
data_generation <- function(n, mu, Cov, theta, R2)
{
  m = nrow(Cov)
  X = MASS::mvrnorm(n, mu, Cov)
  y_h = as.numeric(cbind(1, X) %*% theta)
  sd_e = sqrt((1-R2)/R2*var(y_h))
  e = rnorm(n); e = (e-mean(e))/sd(e); e = sd_e*e
  y = y_h + e
  return(list(X = X, y = y))
}

# It performs hold-out split X into Xref and Xapp with a proportion p_h
split <- function(data, p_h, n)
{
  indices = sample(1:n, floor(n*p_h))
  ref = list(X = data$X[indices, ], y = data$y[indices])
  app0 = list(X = data$X[!(1:n %in% indices), ], y = data$y[!(1:n %in% indices)])
  return(list(ref = ref, app0 = app0))
}

# It injects missing values in Xapp with a proportion pNA.
inject.NA <- function(data, p, type, subtype = NULL)
{
  if(type == "MCAR")
  {
    X = MCAR(data$app0$X, p)
    if(!is.null(subtype)) (warning("no need to indicate subtype if type = MCAR"))
  }
  else if(type == "MNAR")
  {
    X = MNAR(data$app0$X, p, subtype)
    if(is.null(subtype)) (stop("if type = MNAR or MAR, subtype is required"))
  }
  else if(type == "MAR")
  {
    X = MAR(data$app0$X, p, subtype)
    if(is.null(subtype)) (stop("if type = MNAR or MAR, subtype is required"))
  }
  data$app = list(X = X, y = data$app0$y)
  return(data)
}

# MCAR missing values injecting module
MCAR <- function(X, p)
{
  n = nrow(X); m = ncol(X)
  k = 0:(m-1)
  probs = choose(m, k)*p^k*(1-p)^(m-k)/(1-p^m)
  n_missing = sample(k, n, replace = T, prob = probs)
  pos_missing = lapply(1:n, function(x) sample(1:m, n_missing[x], replace = F))
  for(i in 1:n)
  {
    X[i, pos_missing[[i]]] = NA
  }
  return(X)
}

# MNAR missing values injecting module
MNAR <- function(X, p, subtype)
{
  x = as.numeric(X); n = nrow(X); m = ncol(X)
  if(subtype == "R")
  {
    k = uniroot(f = function(k) mean(logistic(x + k)) - p, interval = c(-50, 50))$root
    A = as.numeric(logistic(X + k))
  }
  else if(subtype == "L")
  {
    k = uniroot(f = function(k) mean(logistic(-x + k)) - p, interval = c(-50, 50))$root
    A = as.numeric(logistic(-X + k))
  }
  else if(subtype == "LR")
  {
    k = uniroot(f = function(k) mean(logistic(abs(x) + k)) - p, interval = c(-50, 50))$root
    A = as.numeric(logistic(abs(X) + k))
  }
  else if(subtype == "C")
  {
    k = uniroot(f = function(k) mean(1 - logistic(abs(x) + k)) - p, interval = c(-50, 50))$root
    A = as.numeric(1 - logistic(abs(X) + k))
  }
  res = matrix(sapply(1:length(A), function(x) sample(c(1,0), size = 1, prob = c(A[x], 1 - A[x]))), nrow(X), ncol(X))
  
  # Rescue pattern - all missing values
  S = which(rowMeans(res) == 1)
  if(length(S) > 0)
  {
    res = rescue_pattern(res, A, S)
  }
  X[as.logical(res)] = NA
  
  return(X)
}

# For MNAR/MCAR, samples with all samples missing need to be substituted by
# an allowed missing value pattern (respecting the imposed probabilities).
rescue_pattern <- function(res, A, S)
{
  A = matrix(A, nrow = nrow(res), ncol = ncol(res))
  pattern = permutations(2, ncol(res), c(1,0), repeats.allowed = T) # NOTE: 1=N/A
  pattern = pattern[!(rowSums(pattern) == ncol(pattern)),] # remove all missing variables pattern
  
  for(i in 1:length(S))
  {
    probs = sapply(1:nrow(pattern), function(x) sum(log(A[S[i],]^pattern[x,]*(1-A[S[i],])^(1 - pattern[x,]))))
    probs = exp(probs)
    probs = probs/sum(probs)
    res[S[i],] = pattern[sample(1:nrow(pattern), 1, prob = probs),]
  }
  return(res)
}

# MAR missing values injecting module
MAR <- function(X, p, subtype)
{
  n = nrow(X); m = ncol(X)
  X_mut = matrix(NA, nrow(X), ncol(X))
  for(j in 1:ncol(X)) # Cyclic permutation
  {
    t_vals = (1-j):(m-j)
    t_vals = t_vals[!(t_vals == 0)]
    t = sample(t_vals, 1)
    X_mut[, j] = X[, j + t]
  }
  D = MNAR(X_mut, p, subtype)
  X[is.na(D)] = NA
  return(X)
}

# Logistic function
logistic <- function(x)
{
  1/(1 + exp(-x))
}

# Theta_omega (sweep operator version)
theta_omega <- function(XtX, omega_c)
{
  m = nrow(XtX)-2
  sweep.operator(XtX, k = omega_c)[omega_c,m+2]
}

# Test all
test_all <- function(data, cost_function, mode = 1)
{
  c(test_full(data, cost_function, mode), 
    tryCatch(test_mean_mode(data, cost_function, mode), error=function(e){NA}), 
    tryCatch(test_mice(data, cost_function, mode), error=function(e){NA}), 
    tryCatch(test_cmb_lm(data, cost_function, mode), error=function(e){NA}))
}

# Test full
test_full <- function(data, cost_function, mode = 1)
{
  df = as.data.frame(data$ref$X)
  df$y = data$ref$y
  lm_mod = lm(formula = y ~ ., data = df)
  y_pred = predict(lm_mod, as.data.frame(data$app0$X))
  metric(y_pred, data$app0$y, cost_function, mode)
}

# Test mean-mode
test_mean_mode <- function(data, cost_function, mode = 1)
{
  df = as.data.frame(data$ref$X)
  df$y = data$ref$y
  lm_mod = lm(formula = y ~ ., data = df)
  
  X_impute = data$app$X
  I = is.na(X_impute)
  NA_count = colSums(I)
  means = colMeans(data$app$X, na.rm = T) # population means from the application dataset
  u = sapply(1:length(means), function(x) rep(means[x], NA_count[x]))
  u = unlist(u)
  X_impute[I] = u
  y_pred = predict(lm_mod, as.data.frame(X_impute))
  metric(y_pred, data$app$y, cost_function, mode)
}

# Test mice
test_mice <- function(data, cost_function, mode = 1)
{
  df = as.data.frame(data$ref$X)
  df$y = data$ref$y
  lm_mod = lm(formula = y ~ ., data = df)
  mice_out = mice(data$app$X, m = 1, printFlag = F, method = "pmm", remove.collinear = F)
  data$app$X = complete(mice_out, 1)
  y_pred = predict(lm_mod, as.data.frame(data$app$X))
  metric(y_pred, data$app0$y, cost_function, mode)
}


# Test cmb-lm
test_cmb_lm <- function(data, cost_function, mode = 1)
{
  QR = qr(cbind(1, data$ref$X))
  R = qr.R(QR, complete = F)
  theta = backsolve(r = R, x = t(qr.Q(QR)) %*% data$ref$y)
  m = length(theta)-1
  yty = t(data$ref$y) %*% data$ref$y
  XtX = rbind(cbind(t(R) %*% R, t(R) %*% R %*% theta), c(t(R) %*% R %*% theta, yty))
  
  X_ = cbind(1, data$app$X)
  Indicator = is.na(X_)
  omegaC_list = lapply(1:nrow(Indicator), function(x) (1:(m+1))[!(1:(m+1) %in% which(Indicator[x,]))])
  y_pred = sapply(1:nrow(X_), function(x) na.omit(X_[x,]) %*% theta_omega(XtX, omegaC_list[[x]]))
  metric(y_pred, data$app0$y, cost_function, mode)
}

# Theta_omega (sweep operator version)
theta_omega <- function(XtX, omega_c)
{
  m = nrow(XtX)-2
  sweep.operator(XtX, k = omega_c)[omega_c,m+2]
}

# Metrics (correlation, bias)
metric <- function(pred, obs, cost_function, mode = 1)
{
  if(mode == 1) # cor
  {
    return(cost_function(pred, obs))
  }
  else if(mode == 2) # bias
  {
    return(mean(pred-obs))
  }
}

# Prediction mean square error
MSE = function(x, y)
{
  mean((x-y)^2)
}

# Concordance correlation coefficient
conc_cor <- function(x, y)
{
  return(DescTools::CCC(x, y)$rho.c$est)
}

