############################################################################
############################################################################
###########                                                      ###########
###########          Simulation study, round 1 (aps-lm)          ###########
###########             Author: Benjamin Planterose              ###########
###########                                                      ###########
###########        Erasmus MC University Medical Centre          ###########
###########               Rotterdam, The Netherlands             ###########
###########                                                      ###########
###########              b.planterosejimenez@gmail.com           ###########
###########                                                      ###########
############################################################################
############################################################################

# Load libraries
library(matrixcalc)
library(MASS)
library(gplots)
library(mice)
library(gtools)
library(matrixStats)
library(ggplot2)
library(reshape)
library(Matrix)
library(fastmatrix)

# Load functions
# Common functions
source("common_functions.R")

# Global simulation wrapper
simulation <- function(mu, Cov, theta, p_h, typeNA, subtype, N_iter, conditions, dep)
{
  mus = matrix(0, ncol = 4, nrow = nrow(conditions))
  colnames(mus) = paste("mu", c("full", "mean", "MICE", "cmb_LM"), sep = ":")
  conditions = cbind(conditions, mus)
  
  for(i in 1:nrow(conditions))
  {
    print(paste(i, "out of", nrow(conditions)))
    res = matrix(ncol = 4, nrow = N_iter)
    for(l in 1:N_iter)
    {
      data = simulate_data(conditions[i, 1], mu, Cov, theta, conditions[i, 2], 
                           p_h, conditions[i, 3], typeNA, subtype)
      res[l,] = test_all(data, cor, 1)
    }
    conditions[i, 4:ncol(conditions)] = sapply(1:ncol(res), function(x) paste(round(res[,x], 3), collapse = ", "))
  }
  return(prep_results(conditions, typeNA, subtype, dep, N_iter))
}

# Result parser
prep_results <- function(RES, typeNA, subtype, dep, N_iter)
{
  full = Reduce(rbind, strsplit(RES$`mu:full`, ", "))
  colnames(full) = paste("full", 1:ncol(full), sep = "_")
  mean = Reduce(rbind, strsplit(RES$`mu:mean`, ", "))
  colnames(mean) = paste("mean", 1:ncol(mean), sep = "_")
  MICE = Reduce(rbind, strsplit(RES$`mu:MICE`, ", "))
  colnames(MICE) = paste("MICE", 1:ncol(MICE), sep = "_")
  cmbLM = Reduce(rbind, strsplit(RES$`mu:cmb_LM`, ", "))
  colnames(cmbLM) = paste("cmbLM", 1:ncol(cmbLM), sep = "_")
  
  res = Reduce(cbind, list(RES[,1:3], full, mean, MICE, cmbLM))
  res.m = melt(res, id.vars = c("n","R2", "pNA"))
  res.m$value = as.numeric(res.m$value)
  res.m$variable = sapply(strsplit(as.vector(res.m$variable), "_"), function(x) x[1])
  
  return(res.m)
}


########################## Define Parameters ##########################

m = 10
p_h = 0.8
n_min = ceiling((m+1)/p_h)
n = n_min*seq(2, 20, 2)
R2 = seq(0.2, 0.95, 0.25)
pNA = c(0.05, 0.1, 0.2, 0.3, 0.5, 0.7)
conditions = expand.grid(n, R2, pNA)
colnames(conditions) = c("n", "R2", "pNA")
mu = c(2, 1, 0.2, -2, 3, 0.1, 1.4, -2, 3, 0.001)
theta = c(0.7, -0.4, 2, 0.1, 0.5, -2, 0.5, 3, 0.8, -0.9, 0.01)
N_iter = 50

# Independent
sigma = c(1.42, 0.82, 1.22, 2.22, 1.67, 2, 0.71, 1.8, 0.73, 1.36)
Cov_ind = diag(sigma)

# Medium Dependency
Cov_wd = matrix(c(1.42, -0.16, 0.32, 0.49, 0.3, 0.11, 0.24, -0.64, 0.02, -0.8,
                  -0.16, 0.82, 0.28, -0.82, 0.3, -0.39, 0.23, -0.09, -0.24, -0.14,
                  0.32, 0.28, 1.22, -0.36, 0.78, 0.19, 0.46, -0.34, -0.2, 0.28,
                  0.49, -0.82, -0.36, 2.22, 0.27, 0.75, 0.33, 0.03, 0.31, -0.26,
                  0.3, 0.3, 0.78, 0.27, 1.67, 0.84, 0.44, 0.42, -0.17, -0.16,
                  0.11, -0.39, 0.19, 0.75, 0.84, 2, -0.03, 1.14, 0.03, -0.48,
                  0.24, 0.23, 0.46, 0.33, 0.44, -0.03, 0.71, -0.14, -0.06, -0.05,
                  -0.64, -0.09, -0.34, 0.03, 0.42, 1.14, -0.14, 1.8, -0.03, -0.31,
                  0.02, -0.24, -0.2, 0.31, -0.17, 0.03, -0.06, -0.03, 0.73, 0.09,
                  -0.8, -0.14, 0.28, -0.26, -0.16, -0.48, -0.05, -0.31, 0.09, 1.36),
                nrow = 10, byrow = T)

# Strong Dependency
Cov_sd = matrix(c(1.42, -0.06, 0.58, 0.36, 0.92, -0.12, 0.51, 0.61, -0.02, -0.02,
                  -0.06, 0.82, -0.15, -0.19, -0.09, 0.58, -0.13, -0.14, 0.01, -0.09,
                  0.58, -0.15, 1.22, 0.84, 1.03, -0.58, 0.79, 1.10, -0.05, 0.11,
                  0.36, -0.19, 0.84, 2.22, 0.99, -0.31, 0.73, 1.02, 0.01, 0.28,
                  0.92, -0.09, 1.03, 0.99, 1.67, -0.21, 0.96, 1.17, -0.15, 0.15,
                  -0.12, 0.58, -0.58, -0.31, -0.21, 2, -0.41, -0.42, -0.03, -0.19,
                  0.51, -0.13, 0.79, 0.73, 0.96, -0.41, 0.71, 0.91, -0.11, 0.13,
                  0.61, -0.14, 1.10, 1.02, 1.17, -0.42, 0.91, 1.8, -0.17, 0.06,
                  -0.02, 0.01, -0.05, 0.01, -0.15, -0.03, -0.11, -0.17, 0.73, -0.13,
                  -0.02, -0.09, 0.11, 0.28, 0.15, -0.19, 0.13, 0.06, -0.13, 1.36),
                nrow = 10, byrow = T)

########################## Simulation 1: Independent+MCAR ##########################
start_time <- Sys.time()
set.seed(123)
out1 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MCAR", subtype = NULL, conditions = conditions, 
                  dep = "independent")
########################## Simulation 2: wd+MCAR ##########################
set.seed(124)
out2 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MCAR", subtype = NULL, conditions = conditions, 
                  dep = "WD")
########################## Simulation 3: sd+MCAR ##########################
set.seed(125)
out3 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MCAR", subtype = NULL, conditions = conditions, 
                  dep = "SD")
########################## Simulation 4: Independent+MAR+L ##########################
set.seed(126)
out4 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "L", conditions = conditions, 
                  dep = "independent")
########################## Simulation 5: wd+MAR+L ##########################
set.seed(127)
out5 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "L", conditions = conditions, 
                  dep = "wd")
########################## Simulation 6: sd+MAR+L ##########################
set.seed(128)
out6 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "L", conditions = conditions, 
                  dep = "sd")
########################## Simulation 7: Independent+MAR+LR ##########################
set.seed(129)
out7 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "LR", conditions = conditions, 
                  dep = "independent")
########################## Simulation 8: wd+MAR+LR ##########################
set.seed(130)
out8 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "LR", conditions = conditions, 
                  dep = "wd")
########################## Simulation 9: sd+MAR+LR ##########################
set.seed(131)
out9 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "LR", conditions = conditions, 
                  dep = "sd")
########################## Simulation 10: Independent+MAR+C ##########################
set.seed(132)
out10 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "C", conditions = conditions, 
                  dep = "independent")
########################## Simulation 11: wd+MAR+C ##########################
set.seed(133)
out11 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "C", conditions = conditions, 
                  dep = "wd")
########################## Simulation 12: sd+MAR+C ##########################
set.seed(134)
out12 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MAR", subtype = "C", conditions = conditions, 
                  dep = "sd")
########################## Simulation 13: Independent+MNAR+L ##########################
set.seed(135)
out13 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "L", conditions = conditions, 
                  dep = "independent")
########################## Simulation 14: wd+MNAR+L ##########################
set.seed(136)
out14 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "L", conditions = conditions, 
                  dep = "wd")
########################## Simulation 15: sd+MNAR+L ##########################
set.seed(137)
out15 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "L", conditions = conditions, 
                  dep = "sd")
########################## Simulation 16: Independent+MNAR+LR ##########################
set.seed(138)
out16 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "LR", conditions = conditions, 
                  dep = "independent")
########################## Simulation 17: wd+MNAR+LR ##########################
set.seed(139)
out17 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "LR", conditions = conditions, 
                  dep = "wd")
########################## Simulation 18: sd+MNAR+LR ##########################
set.seed(140)
out18 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "LR", conditions = conditions, 
                  dep = "sd")
########################## Simulation 19: Independent+MNAR+C ##########################
set.seed(141)
out19 = simulation(mu = mu, Cov = Cov_ind, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "C", conditions = conditions, 
                  dep = "independent")

########################## Simulation 20: wd+MNAR+C ##########################
set.seed(142)
out20 = simulation(mu = mu, Cov = Cov_wd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "C", conditions = conditions, 
                  dep = "wd")
########################## Simulation 21: sd+MNAR+C ##########################
set.seed(143)
out21 = simulation(mu = mu, Cov = Cov_sd, theta = theta, p_h = p_h, N_iter = N_iter,
                  typeNA = "MNAR", subtype = "C", conditions = conditions, 
                  dep = "sd")
end_time <- Sys.time()
end_time - start_time # Time difference of 21.84888 hours

################################## Save results ##################################

out = list(out1 = out1,   out2 = out2,   out3 = out3,   out4 = out4,   out5 = out5,
           out6 = out6,   out7 = out7,   out8 = out8,   out9 = out9,   out10 = out10, 
           out11 = out11, out12 = out12, out13 = out13, out14 = out14, out15 = out15, 
           out16 = out16, out17 = out17, out18 = out18, out19 = out19, out20 = out20, 
           out21 = out21)
saveRDS(out, "round1.Rds")

################################## Session Info ##################################

sessionInfo()
# R version 4.1.2 (2021-11-01)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: Ubuntu 18.04.5 LTS
# 
# Matrix products: default
# BLAS:   /usr/lib/x86_64-linux-gnu/blas/libblas.so.3.7.1
# LAPACK: /usr/lib/x86_64-linux-gnu/lapack/liblapack.so.3.7.1
# 
# locale:
# [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C               LC_TIME=nl_NL.UTF-8        LC_COLLATE=en_US.UTF-8    
# [5] LC_MONETARY=nl_NL.UTF-8    LC_MESSAGES=en_US.UTF-8    LC_PAPER=nl_NL.UTF-8       LC_NAME=C                 
# [9] LC_ADDRESS=C               LC_TELEPHONE=C             LC_MEASUREMENT=nl_NL.UTF-8 LC_IDENTIFICATION=C       
# 
# attached base packages:
# [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
# [1] fastmatrix_0.3-8196 Matrix_1.3-4        reshape_0.8.8       ggplot2_3.3.5       matrixStats_0.61.0 
# [6] gtools_3.9.2        mice_3.13.0         gplots_3.1.1        MASS_7.3-54         matrixcalc_1.0-5   
# 
# loaded via a namespace (and not attached):
# [1] backports_1.3.0             BiocFileCache_2.0.0         plyr_1.8.6                  splines_4.1.2              
# [5] BiocParallel_1.26.2         GenomeInfoDb_1.28.4         digest_0.6.28               foreach_1.5.1              
# [9] fansi_0.5.0                 magrittr_2.0.1              memoise_2.0.0               tzdb_0.2.0                 
# [13] limma_3.48.3                Biostrings_2.60.2           readr_2.1.0                 annotate_1.70.0            
# [17] askpass_1.1                 siggenes_1.66.0             prettyunits_1.1.1           colorspace_2.0-2           
# [21] blob_1.2.2                  rappdirs_0.3.3              dplyr_1.0.7                 crayon_1.4.2               
# [25] RCurl_1.98-1.5              genefilter_1.74.1           lme4_1.1-27.1               GEOquery_2.60.0            
# [29] survival_3.2-13             iterators_1.0.13            glue_1.5.0                  gtable_0.3.0               
# [33] zlibbioc_1.38.0             XVector_0.32.0              DelayedArray_0.18.0         Rhdf5lib_1.14.2            
# [37] BiocGenerics_0.38.0         HDF5Array_1.20.0            scales_1.1.1                jomo_2.7-2                 
# [41] abind_1.4-5                 mvtnorm_1.1-3               DBI_1.1.1                   rngtools_1.5.2             
# [45] Rcpp_1.0.7                  xtable_1.8-4                progress_1.2.2              bumphunter_1.34.0          
# [49] bit_4.0.4                   mclust_5.4.8                preprocessCore_1.54.0       stats4_4.1.2               
# [53] httr_1.4.2                  RColorBrewer_1.1-2          ellipsis_0.3.2              farver_2.1.0               
# [57] pkgconfig_2.0.3             XML_3.99-0.8                dbplyr_2.1.1                locfit_1.5-9.4             
# [61] utf8_1.2.2                  tidyselect_1.1.1            rlang_0.4.12                AnnotationDbi_1.54.1       
# [65] munsell_0.5.0               tools_4.1.2                 cachem_1.0.6                generics_0.1.1             
# [69] RSQLite_2.2.8               broom_0.7.10                stringr_1.4.0               mvmeta_1.0.3               
# [73] fastmap_1.1.0               yaml_2.2.1                  bit64_4.0.5                 beanplot_1.2               
# [77] caTools_1.18.2              scrime_1.3.5                purrr_0.3.4                 KEGGREST_1.32.0            
# [81] nlme_3.1-153                doRNG_1.8.2                 sparseMatrixStats_1.4.2     nor1mix_1.3-0              
# [85] xml2_1.3.2                  biomaRt_2.48.3              compiler_4.1.2              rstudioapi_0.13            
# [89] filelock_1.0.2              curl_4.3.2                  png_0.1-7                   tibble_3.1.6               
# [93] stringi_1.7.5               GenomicFeatures_1.44.2      minfi_1.38.0                lattice_0.20-45            
# [97] nloptr_1.2.2.3              multtest_2.48.0             vctrs_0.3.8                 pillar_1.6.4               
# [101] lifecycle_1.0.1             rhdf5filters_1.4.0          data.table_1.14.2           bitops_1.0-7               
# [105] micemd_1.8.0                rtracklayer_1.52.1          mixmeta_1.2.0               GenomicRanges_1.44.0       
# [109] R6_2.5.1                    BiocIO_1.2.0                KernSmooth_2.23-20          IRanges_2.26.0             
# [113] codetools_0.2-18            boot_1.3-28                 assertthat_0.2.1            rhdf5_2.36.0               
# [117] SummarizedExperiment_1.22.0 openssl_1.4.5               rjson_0.2.20                withr_2.4.2                
# [121] GenomicAlignments_1.28.0    Rsamtools_2.8.0             S4Vectors_0.30.2            GenomeInfoDbData_1.2.6     
# [125] parallel_4.1.2              hms_1.1.1                   quadprog_1.5-8              grid_4.1.2                 
# [129] tidyr_1.1.4                 base64_2.0                  minqa_1.2.4                 DelayedMatrixStats_1.14.3  
# [133] illuminaio_0.34.0           MatrixGenerics_1.4.3        Biobase_2.52.0              restfulr_0.0.13  
