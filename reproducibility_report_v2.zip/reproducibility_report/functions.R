# Convert covariance matrix to correlation matrix
cov_to_cor = function(Cov)
{
  D = diag(sqrt(diag(Cov)))
  solve(D) %*% Cov %*% solve(D)
}

# Compute normalized entropy of a covariance matrix
norm_entropy <- function(Cov)
{
  m = nrow(Cov)
  l = eigen(Cov/(sqrt(diag(Cov)) %*% t(sqrt(diag(Cov)))))$values/m
  -sum(l*log(l)/log(m))
}

# Compute Gini-Simpson Index of a covariance matrix
norm_ginisimpson <- function(Cov)
{
  m = nrow(Cov)
  l = eigen(Cov/(sqrt(diag(Cov)) %*% t(sqrt(diag(Cov)))))$values/m
  l_max = rep(1/m, m)
  (1-sum(l^2))/(1-sum(l_max^2))
}

# Visualize output from simulation - round 1
visualize_round1 <- function(res.m, typeNA, subtype, dep, N_iter)
{
  ggplot(data = res.m, mapping = aes(x = n, y = value^2, col = variable)) +
    facet_wrap(R2 ~ pNA, ncol = 6, labeller = labeller(pNA = label_both, R2 = label_both)) + 
    geom_point(alpha = 0.1, size = 0.1) + geom_smooth(alpha = 0.5, method = "loess", level = 0.95, span = 10) +
    theme(legend.text=element_text(size=8),
          strip.text = element_text(size = 7),
          plot.title = element_text(hjust = 0.5),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
    ggtitle(paste("Cov = ", dep, ", N_iter = ", N_iter, 
                  ", typeNA = ", typeNA, ", subtypeNA = ", c("NULL", subtype)[1+!is.null(subtype)],
                  sep = "")) +
    ylab("cor^2(y_hat, y)") + ylim(c(0,1))
}

# Visualize output from simulation - round 2 (bias)
visualize_round2_bias = function(res.m2, dep, N_iter, linewidth = 1, alpha = 0.3, ref = "cmb_LM")
{
  res.m2$model = relevel(res.m2$model, ref = ref)
  g4 = ggplot(data = res.m2, mapping = aes(x = pNA, y = value, col = model)) + 
    geom_point(alpha = 0.1, size = 0.1) + 
    geom_smooth(alpha = alpha, method = "loess", level = 0.95, linewidth = linewidth) +
    facet_wrap(~ typeNA) + 
    theme(legend.text=element_text(size=8),
          strip.text = element_text(size = 7),
          plot.title = element_text(hjust = 0.5),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
    ggtitle(paste("Cov = ", dep, ", N_iter = ", N_iter,
                  sep = "")) + ylab("Bias")
  return(g4)
  
}

# Visualize output from simulation - round 2 (cor or concordance)
visualize_round2_cor2 = function(res.m1, dep, N_iter, linewidth = 1, 
                                 alpha = 0.3, ref = "cmb_LM", ylab = "cor^2(y_hat, y)")
{
  res.m1$model = relevel(res.m1$model, ref = ref)
  
  g2 = ggplot(data = res.m1, mapping = aes(x = pNA, y = value^2, col = model)) + 
    geom_point(alpha = 0.1, size = 0.1) + 
    geom_smooth(alpha = alpha, method = "loess", level = 0.95, linewidth = linewidth) +
    facet_wrap(~ typeNA) + ylim(0,1) + 
    theme(legend.text=element_text(size=8),
          strip.text = element_text(size = 7),
          plot.title = element_text(hjust = 0.5),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
    ggtitle(paste("Cov = ", dep, ", N_iter = ", N_iter,
                  sep = "")) + ylab(ylab) 
  return(g2)
}

# Visualize output from simulation - round 2 (MSE)
visualize_round2_MSE = function(res.m1, dep, N_iter, linewidth = 1, alpha = 0.3, ref = "cmb_LM")
{
  res.m1$model = relevel(res.m1$model, ref = ref)
  g2 = ggplot(data = res.m1, mapping = aes(x = pNA, y = value, col = model)) + 
    geom_point(alpha = 0.1, size = 0.1) + 
    geom_smooth(alpha = alpha, method = "loess", level = 0.95, linewidth = linewidth) +
    facet_wrap(~ typeNA) + 
    theme(legend.text=element_text(size=8),
          strip.text = element_text(size = 7),
          plot.title = element_text(hjust = 0.5),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
    ggtitle(paste("Cov = ", dep, ", N_iter = ", N_iter,
                  sep = "")) + scale_y_continuous(trans = 'log10', limits = c(0.1,100)) + ylab("MSE") 
  return(g2)
}

# Compute R2 of a submodel with missing covariates omega.
compute_R2_omega = function(mu, Cov, theta, R2, omega, n)
{
  mu = c(1, mu)
  Cov = rbind(0, cbind(0, Cov))
  R = chol(n*Cov + n*mu %*% t(mu))
  var_y_tilde_emptyset = t(theta) %*% Cov %*% theta
  sigma_epsilon_emptyset = sqrt((1-R2)/R2*var_y_tilde_emptyset)
  var_y = var_y_tilde_emptyset + sigma_epsilon_emptyset^2
  m = ncol(Cov)-1 # -1 because (intercept) column/row was added before
  omega_c = (1:(m+1))[!(1:(m+1) %in% (omega+1))]
  theta_omega = MASS::ginv(R[,omega_c]) %*% R %*% theta
  var_y_tilde_omega = t(theta_omega) %*% Cov[omega_c, omega_c] %*% theta_omega
  R2_Omega = var_y_tilde_omega/var_y
  return(as.numeric(R2_Omega))
}

# Visualize output from simulation - round 4
visualize_round4 <- function(res.m, dep, N_cov, N_rep, confidence, conditions)
{
  res.m$variable = factor(res.m$variable, levels = c("CI", "PI"))
  res.m$n = factor(res.m$n, levels = sort(unique(res.m$n), decreasing = F))
  res.m$R2_omega = 0
  for(i in 1:nrow(res.m))
  {
    res.m$R2_omega[i] = conditions[(conditions$R2 == res.m$R2[i]) &
                                     (conditions$Omega == res.m$omega[i]) &
                                     (conditions$Cov == dep) & 
                                     (conditions$n == res.m$n[i]),]$R2_omega
  }
  res.m$R2_omega = round(res.m$R2_omega, 3)
  res.m$n = factor(res.m$n, levels = sort(unique(res.m$n), decreasing = F))
  
  
  p1 = ggplot(data = res.m, mapping = aes(x = variable, y = value, col = n, fill = n)) +
    facet_wrap(omega ~ R2+R2_omega, ncol = length(unique(res.m$R2)), labeller = labeller(omega = label_both, R2 = label_both, R2_omega = label_both)) + 
    geom_hline(yintercept = confidence, linetype = 3, col = "gray2") + 
    geom_boxplot(outlier.alpha = 0.5, outlier.size = 0.5) +
    theme(legend.text=element_text(size=8),
          strip.text = element_text(size = 7),
          plot.title = element_text(hjust = 0.5),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
    ggtitle(paste("Cov = ", dep, ", N_cov = ", N_cov, ", N_rep = ", N_rep,
                  sep = "")) + 
    ylab("Coverage") + 
    scale_y_continuous(breaks = c(0.9, 0.95, 1), limits = c(0.9, 1))
  
  return(p1)
}

# Visualize output from application missing data injection (bias)
visualize_results_app_bias <- function(RES_glob)
{
  p0 = 0.04190432
  cbPalette = c('lightcoral', 'indianred3', 'lightpink4', 'lightpink',
                'darkslategray1', 'darkturquoise', 'deepskyblue1', 'deepskyblue4')
  (g2 <- ggplot(data=RES_glob, aes(x=pNA, y=bias, col=method_model)) + geom_hline(yintercept = 0, linetype = "dashed") +
      geom_point(alpha = 0.2, size = 0.7) + geom_smooth(method = 'loess', level = 0.95, linewidth = 0.5, span = 0.4, alpha = 0.3) +
      geom_vline(xintercept = p0, linetype = 'dashed', col = 'gray2') +
      scale_colour_manual(values=cbPalette))
}

# Visualize output from application missing data injection (MSE)
visualize_results_app_MSE <- function(RES_glob)
{
  p0 = 0.04190432
  cbPalette = c('lightcoral', 'indianred3', 'lightpink4', 'lightpink',
                'darkslategray1', 'darkturquoise', 'deepskyblue1', 'deepskyblue4')
  (g1 <- ggplot(data=RES_glob, aes(x=pNA, y=rho, col=method_model)) + xlim(0,1) + 
      geom_point(alpha = 0.2, size = 0.7) + geom_smooth(method = 'loess', level = 0.95, linewidth = 0.5, span = 0.4, alpha = 0.3) +
      geom_vline(xintercept = p0, linetype = 'dashed', col = 'gray2') + scale_y_continuous(trans = 'log10', limits = c(10, 1000)) + ylab("MSE") +
      scale_colour_manual(values=cbPalette))
}

